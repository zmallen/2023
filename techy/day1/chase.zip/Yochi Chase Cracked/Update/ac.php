<?php
$ib = $_SERVER['REMOTE_ADDR'];
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";
logbot('TRICKED BOT');banbot();
?>